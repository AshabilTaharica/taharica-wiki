<?php get_header('secondary');?>


<section class="page">
    <div class="container bg-light p-4">


       <h1> <?php  the_title(); ?></h1>

        <?php get_template_part('includes/section', 'blogcontent');?>



    </div>
</section>

<?php get_footer();?>