<?php get_header('secondary'); ?>

<section class="page">
    <div class="container bg-light p-5">
        <h1><?php the_title(); ?></h1>

        <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
            <?php the_content(); ?>
        <?php endwhile; else : endif; ?>

        <a href="http://taharicawiki.test/wp-admin/post-new.php" target="_blank"> Create Post</a>

        <?php
        // Cek apakah parameter page adalah "it", "hr", "engineering", atau "hadist"
        $page_slug = get_query_var('pagename');  // Mendapatkan slug halaman
        $allowed_categories = array('it', 'hr', 'engineering', 'hadist');

        if (in_array($page_slug, $allowed_categories)) {
            // Dapatkan ID kategori berdasarkan slug halaman
            $category = get_category_by_slug($page_slug);
            $category_id = $category->term_id;

            // Dapatkan semua tags terkait dengan kategori
            $tags = get_tags(array(
                'taxonomy' => 'post_tag',
                'object_ids' => get_posts(array(
                    'category' => $category_id,
                    'fields' => 'ids',
                )),
            ));

            // Tampilkan daftar tags
            if ($tags) :
                echo '<ul>';
                foreach ($tags as $tag) :
                    echo '<li><a href="' . get_tag_link($tag->term_id) . '">' . $tag->name . '</a></li>';
                endforeach;
                echo '</ul>';
            else :
                echo '<p>No tags found for the selected category.</p>';
            endif;
        }
        ?>
    </div>
</section>

<?php get_footer(); ?>
